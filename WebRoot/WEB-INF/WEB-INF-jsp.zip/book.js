function clearSearch()
{
	
}